# - MX-ManyRoads-exe-v1.4 setup
 - open conky manager
 - import file.zip in the conky manager
 - check all 5 box in the conky manager list from MX-ManyRoads-exe-v1.4
 - enjoy !
