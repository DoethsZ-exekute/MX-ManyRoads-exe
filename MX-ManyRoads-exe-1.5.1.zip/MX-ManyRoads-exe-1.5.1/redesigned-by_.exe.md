https://n1m.com/3x3
.exe electronic instrumental music producer

Installation
use conky manager
import the .zip file
enjoy !
